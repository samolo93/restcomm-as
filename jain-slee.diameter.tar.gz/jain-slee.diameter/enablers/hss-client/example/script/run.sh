sipp -trace_err -sf uas.xml -i 127.0.0.1 -p 5090 -r 1 -m 100000000000000
